# CS 6476 project 4: [Scene Recognition with Bag-of-Words](https://www.cc.gatech.edu/~hays/compvision/proj4/)

# Setup
- Install Anaconda / Miniconda
- Create a conda environment using the given file: `conda env create -f environment_<OS>.yml`
- This should create an environment named `cs6476p4`. Activate it using `activate cs6476p4`
